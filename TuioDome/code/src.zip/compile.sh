#!/bin/sh
javac -O -source 1.4 -target 1.4  -cp javaosc.jar:core.jar tuio/*.java
jar cf tuio.jar tuio/*.class
rm tuio/*.class

